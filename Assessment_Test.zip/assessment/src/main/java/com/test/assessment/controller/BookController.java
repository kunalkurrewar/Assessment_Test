package com.test.assessment.controller;

import com.test.assessment.entity.Book;
import com.test.assessment.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")
public class BookController {
    @Autowired
    private BookService bookService;

    @GetMapping
    public Flux<Book> getAllBooks(Book book) {
        return bookService.getAllBooks(book);
    }

    @GetMapping("/{id}")
    public Flux<Book> getBookById(@PathVariable String id) {
        return bookService.getBookById(Long.valueOf(id));
    }
    @PostMapping
    public Flux<Book> createBook(@RequestBody Book book) {
        return bookService.createBook(book);
    }
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable String id, @RequestBody Book book) {
        return bookService.updateBook(id, book);
    }
    @DeleteMapping("/{id}")
    public Mono<Void> deleteBook(@PathVariable String id) {
        return bookService.deleteBook(id).then();
    }
}

