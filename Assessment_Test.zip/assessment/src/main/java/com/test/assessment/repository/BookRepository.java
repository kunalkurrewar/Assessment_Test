package com.test.assessment.repository;

import com.test.assessment.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
@Repository
public interface BookRepository extends JpaRepository<Book,Long> {
    Flux<Book> findAll(Book book);

    Flux<Book> findAll(Long id);
    Flux<Book> save();

    Flux<Void> deleteById(String id);
}
