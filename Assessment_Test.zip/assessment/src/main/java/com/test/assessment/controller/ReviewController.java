package com.test.assessment.controller;

import com.test.assessment.entity.Review;
import com.test.assessment.service.ReviewService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;

@RestController
@RequestMapping("/api")
public class ReviewController {
    @Autowired
    private ReviewService reviewService;

    @GetMapping
    public Flux<Review> getAllReview(Review review) {
        return reviewService.getAllReview(review);
    }

    @GetMapping("/{id}")
    public Flux<Review> getReviewById(@PathVariable String id) {
        return reviewService.getReviewById(Long.valueOf(id));
    }

    @PostMapping
    public Flux<Review> createReview(@RequestBody Review review) {
        return reviewService.createReview(review);
    }
    @PutMapping("/{id}")
    public Review updateReview(@PathVariable String id, @RequestBody Review review) {
        return reviewService.updateReview(id, review);
    }
    @DeleteMapping("/{id}")
    public Flux<Void> deleteReview(@PathVariable String id) {
        return reviewService.deleteReview(Long.valueOf(id));
    }
}
